import React from "react";

function AlternativeAffairs(props: any) {
    return (
        <div>
        </div>
    );
}

export default AlternativeAffairs;
